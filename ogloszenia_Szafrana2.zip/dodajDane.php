<?php
    $polacz = mysqli_connect('localhost', 'root', '', 'ogloszenia');
    $imie=$_POST['imie'];
    $nazwisko=$_POST['nazwisko'];
    $telefon=$_POST['telefon'];
    $email=$_POST['email'];
    $zapytanie1="INSERT INTO uzytkownik VALUES(null,'$imie','$nazwisko','$telefon','$email'); ";
    $zapytanie1=mysqli_query($polacz,$zapytanie1);
?>