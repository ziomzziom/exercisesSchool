<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteka miejska</title>
    <link rel="stylesheet" href="style.css">
    <?php
        $polacz = mysqli_connect('localhost', 'root', '', 'biblioteka');

        $pytanie1 = "SELECT imie, nazwisko FROM autorzy;";
        $zapytanie1 = mysqli_query($polacz,$pytanie1);
        $dane1 = mysqli_fetch_array($zapytanie1);

        $imie=$_POST['imie'];
        $nazwisko=$_POST['nazwisko'];
        $rok = $_POST['rok'];

        $kod = strtoupper(substr($imie,0,2).substr($nazwisko,0,2).substr($rok,-2));

        $pytanie2 = "INSERT INTO czytelnicy VALUES (null, '$imie', '$nazwisko', '$kod'); ";
        $zapytanie2 = mysqli_query($polacz,$pytanie2);

        mysqli_close($polacz);
    ?>
</head>
<body>
    <div class="container">
        <div class="baner">
            <h2>Miejska Biblioteka Publiczna w Książkowicach</h2>
        </div>
        <div class="lewy">
            <h3>naszych zbiorach znajdziesz dzieła następujących autorów:</h3>
            <ul>
                <?php
                    do{
                        echo "<li>".$dane1[0]." ".$dane1[1]."</li>";
                    }while($dane1=mysqli_fetch_array($zapytanie1));
                ?>
            </ul>
        </div>
        <div class="srodkowy">
            <h3>Dodaj nowego czytelnika</h3>
            <form action="biblioteka.php" method="post">
                <p>Imię: <input type="text" name="imie"></p>
                <p>Nazwisko: <input type="text" name="nazwisko"></p>
                <p>Rok urodzenia: <input type="number" name="rok"></p>
                <button type="submit">Dodaj</button>
            </form>
            <?php
                echo "<h4>Czytelnik: ".$imie." ".$nazwisko." ".$kod." został dodany do bazy danych </h4>";
            ?>
        </div>
        <div class="prawy">
            <img src="biblioteka.png" alt="ksiazki">
            <h4>
                <p>ul. Czytelnicza 25</p>
                <p>12-120 Książkowice</p>
                <p>tel.: 123123123</p>
                <p>e-mail: <a href="mailto:biuro@biblioteka.pl">biuro@biblioteka.pl</a></p>
            </h4>
        </div>
        <div class="stopka">
            <p>Projekt strony: 000000000000</p>
        </div>
    </div>
    
</body>
</html>