<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hurtownia papiernicza</title>
    <link rel="stylesheet" href="styl.css">
    <?php
        $polacz = mysqli_connect('localhost', 'root', '', 'hurtownia');
        $zapytanie1=mysqli_query($polacz, "SELECT towary.nazwa, towary.cena FROM towary LIMIT 4; ");
        $dane1 = mysqli_fetch_array($zapytanie1);

        $nazwa=$_POST['nazwa'];
        $liczba=$_POST['liczba'];
    
        $zapytanie2=mysqli_query($polacz, "SELECT towary.cena FROM towary WHERE towary.nazwa = '$nazwa'; ");
        $dane2=mysqli_fetch_array($zapytanie2);

        mysqli_close($polacz);
    ?>
</head>
<body>
    <div class="container">
        <div class="baner">
            <h1>W naszej hurtowni kupisz najtaniej</h1>
        </div>
        <div class="lewy">
            <h3>Ceny wybranych artykułów w hurtowni:</h3>
            <table>
                <?php
                    do{
                        echo "<tr>"."<td>".$dane1[0]."</td>"."<td>". $dane1[1]." zł"."</td></tr>";
                    }while($dane1=mysqli_fetch_array($zapytanie1))
                ?>
            </table>
        </div>
        <div class="srodkowy">
            <h3>Ile będą kosztować Twoje zakupy?</h3>
            <form action="index.php" method="post">
                <p>Wybierz artykuł <select name="nazwa" id="">
                    <option value="Zeszyt 60 kartek">Zeszyt 60 kartek</option>
                    <option value="Zeszyt 32 kartki">Zeszyt 32 kartki</option>
                    <option value="Cyrkiel">Cyrkiel</option>
                    <option value="Linijka 30 cm">Linijka 30 cm</option>
                    <option value="Ekierka">Ekierka</option>
                    <option value="Linijka 50 cm">Linijka 50 cm</option>
                </select></p>
                <p>Liczba sztuk: <input type="number" name="liczba" id="" value="1"></p>
                <input type="submit" value="OBLICZ">
            </form>
            <?php
                $wynik=$dane2[0]*$liczba;
                round($wynik, 1);
                echo "Cena wynosi: "."$wynik"." zł";
            ?>
        </div>
        <div class="prawy">
            <img src="zakupy.png" alt="hurtownia">
            <h3>Kontakt</h3>
            <p>telefon:</p>
            <p>111222333</p>
            <p>e-mail:</p>
            <p><a href="mailto:hurt@wp.pl">hurt@wp.pl</a></p>
        </div>
        <div class="stopka">
            <h4>Witrynę wykonał: 000000000000</h4>
        </div>
    </div>
</body>
</html>