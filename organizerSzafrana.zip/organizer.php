<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organizer</title>
    <link rel="stylesheet" href="styl6.css">
    <?php
        $polacz = mysqli_connect('localhost', 'root', '','organizer');
    ?>
</head>
<body>
    <div class="baner1">
        <h2>MÓJ ORGANIZER</h2>
    </div>
    <div class="baner2">
        <form action="organizer.php" method="post">
            <p>Wpis wydarzenia: <input type="text" name="wpis"> <button type="submit">ZAPISZ</button></p>
        </form>
    </div>
    <div class="baner3">
        <img src="logo2.png" alt="Mój organizer">
    </div>
    <div class="glowny">
        <!--skrypt-->
        <?php
            $wpis = $_POST['wpis'];
            $pytanie1 = "SELECT zadania.dataZadania, zadania.miesiac, zadania.wpis 
            FROM zadania WHERE zadania.wpis = '$wpis' ";
            $zapytanie1 = mysqli_query($polacz, $pytanie1);
            $dane1 = mysqli_fetch_array($zapytanie1);
            do{
                echo 
                    "<div class='dzien'>
                        <h6>$dane1[0] $dane1[1]</h6>
                        <p>$dane1[2]</p>
                    </div>";
            }while($dane1 = mysqli_fetch_array($zapytanie1));
        ?>
    </div>
    <div class="stopka">
        <!--skrypt-->
        <?php
            $pytanie2 = "SELECT zadania.miesiac, zadania.rok 
            FROM zadania WHERE zadania.dataZadania = '2020-08-01'; ";
            $zapytanie2 = mysqli_query($polacz, $pytanie2);
            $dane2 = mysqli_fetch_array($zapytanie2);
            echo "<h1>miesiąc: $dane2[0], rok: $dane2[1]</h1>";
            mysqli_close($polacz);
        ?>
        <p>Stronę wykonał: Szafran Software</p>
    </div>
</body>
</html>