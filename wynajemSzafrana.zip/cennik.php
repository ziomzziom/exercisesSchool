<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pokoje</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <div class="container">
        <div class="baner1">
            <h2>Wynajem pokoi</h2>
        </div>
        <div class="menu1">
            <a href="index.html">POKOJE</a>
        </div>
        <div class="menu2">
            <a href="cennik.php">CENNIK</a>
        </div>
        <div class="menu3">
            <a href="kalkulator.html">KALKULATOR</a>
        </div>
        
        <div class="baner2">
            
        </div>
        <div class="lewy"></div>
        <div class="srodkowy">
            <h1>Cennik</h1>
            <table>
                <?php
                    $polacz= mysqli_connect('localhost','root','','wynajem');
                    $zapytanie1 = mysqli_query($polacz, "SELECT * FROM `pokoje`;");
                    $dane1 = mysqli_fetch_array($zapytanie1);
                    do{
                        echo "<tr>"."<td>".$dane1[0]."</td>"."<td>".$dane1[1]."</td>"."<td>".$dane1[2]."</td>"."</tr>";
                    }while($dane1=mysqli_fetch_array($zapytanie1));
                ?>
            </table>
        </div>
        <div class="prawy"></div>
        <div class="stopka">
            <p>Stronę opracował: 00000000000</p>
        </div>
    </div>
</body>
</html>