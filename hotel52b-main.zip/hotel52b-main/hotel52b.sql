-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 22 Lis 2022, 09:16
-- Wersja serwera: 10.4.22-MariaDB
-- Wersja PHP: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `hotel52b`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `klienci`
--

CREATE TABLE `klienci` (
  `id` int(6) NOT NULL,
  `imie` varchar(15) NOT NULL,
  `nazwisko` varchar(20) NOT NULL,
  `kod_pocztowy` char(6) NOT NULL,
  `miasto` varchar(30) NOT NULL,
  `ulica` varchar(30) NOT NULL,
  `nr_domu` char(4) NOT NULL,
  `nr_mieszkania` char(4) DEFAULT NULL,
  `telefon` char(12) NOT NULL,
  `konto` char(26) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `klienci`
--

INSERT INTO `klienci` (`id`, `imie`, `nazwisko`, `kod_pocztowy`, `miasto`, `ulica`, `nr_domu`, `nr_mieszkania`, `telefon`, `konto`) VALUES
(1, 'El?bieta', 'Kosi?ska', '20-441', 'Lublin', 'Zimna', '8a', '', '504123672', '02249000005000046008316877'),
(2, 'Edward', 'Mroczek', '20-100', 'Lublin', 'Rac?awickie', '12', '', '663123672', '24449000005000046008316877');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `platnosci`
--

CREATE TABLE `platnosci` (
  `id` int(2) NOT NULL,
  `nazwa` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `platnosci`
--

INSERT INTO `platnosci` (`id`, `nazwa`) VALUES
(3, 'blik'),
(1, 'got?wka'),
(4, 'karta'),
(2, 'przelew');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pokoje`
--

CREATE TABLE `pokoje` (
  `id` int(3) NOT NULL,
  `numer` char(4) NOT NULL,
  `standard` enum('standard','lux','apartament') NOT NULL,
  `osoby` enum('1','2','3') NOT NULL,
  `czy_z_lazienka` tinyint(1) NOT NULL DEFAULT 1,
  `cena` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `pokoje`
--

INSERT INTO `pokoje` (`id`, `numer`, `standard`, `osoby`, `czy_z_lazienka`, `cena`) VALUES
(1, '100', 'standard', '1', 0, '198.00'),
(2, '101', 'standard', '2', 0, '270.00'),
(3, '103', 'lux', '2', 0, '310.00'),
(4, '104', 'lux', '3', 0, '390.00'),
(5, '105', 'apartament', '3', 0, '510.00'),
(6, '200', 'standard', '1', 0, '180.00'),
(7, '201', 'standard', '2', 0, '245.00'),
(8, '203', 'lux', '3', 0, '280.00'),
(9, '204', 'apartament', '3', 0, '460.00'),
(10, '205', 'apartament', '3', 0, '460.00');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownicy`
--

CREATE TABLE `pracownicy` (
  `id` int(3) NOT NULL,
  `imie_pracownika` varchar(15) NOT NULL,
  `nazwisko_pracownika` varchar(20) NOT NULL,
  `stanowisko_id` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `pracownicy`
--

INSERT INTO `pracownicy` (`id`, `imie_pracownika`, `nazwisko_pracownika`, `stanowisko_id`) VALUES
(1, 'Janusz', 'Kowalski', 1),
(2, 'Eliza', 'Krawczyk', 1),
(3, 'Szymon', 'Galowy', 3);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `rachunki`
--

CREATE TABLE `rachunki` (
  `id` int(6) NOT NULL,
  `data_wystawienia` date NOT NULL,
  `rezerwacje_id` int(6) NOT NULL,
  `dni` int(3) NOT NULL,
  `cena` decimal(6,2) NOT NULL,
  `wartosc` decimal(8,2) NOT NULL,
  `zaliczka` decimal(6,2) NOT NULL,
  `do_zaplaty` decimal(8,2) NOT NULL,
  `pracownik_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `rezerwacje`
--

CREATE TABLE `rezerwacje` (
  `id` int(6) NOT NULL,
  `klient_id` int(6) NOT NULL,
  `pokoj_id` int(3) NOT NULL,
  `data_od` date NOT NULL,
  `data_do` date NOT NULL,
  `zaliczka` decimal(6,2) DEFAULT NULL,
  `pracownik_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `rezerwacje`
--

INSERT INTO `rezerwacje` (`id`, `klient_id`, `pokoj_id`, `data_od`, `data_do`, `zaliczka`, `pracownik_id`) VALUES
(1, 3, 103, '2022-11-19', '2022-11-22', '200.00', 3);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `stanowiska`
--

CREATE TABLE `stanowiska` (
  `id` int(2) NOT NULL,
  `nazwa_stanowiska` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Zrzut danych tabeli `stanowiska`
--

INSERT INTO `stanowiska` (`id`, `nazwa_stanowiska`) VALUES
(1, 'kierownik'),
(3, 'pokojowy'),
(2, 'recepcjonista');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `klienci`
--
ALTER TABLE `klienci`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nazwisko` (`nazwisko`);

--
-- Indeksy dla tabeli `platnosci`
--
ALTER TABLE `platnosci`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nazwa` (`nazwa`);

--
-- Indeksy dla tabeli `pokoje`
--
ALTER TABLE `pokoje`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `numer` (`numer`);

--
-- Indeksy dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `rachunki`
--
ALTER TABLE `rachunki`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rezerwacje_id` (`rezerwacje_id`);

--
-- Indeksy dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pokoj_id_2` (`pokoj_id`,`data_od`),
  ADD KEY `klient_id` (`klient_id`),
  ADD KEY `pokoj_id` (`pokoj_id`),
  ADD KEY `pracownik_id` (`pracownik_id`);

--
-- Indeksy dla tabeli `stanowiska`
--
ALTER TABLE `stanowiska`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nazwa_stanowiska` (`nazwa_stanowiska`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `klienci`
--
ALTER TABLE `klienci`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT dla tabeli `platnosci`
--
ALTER TABLE `platnosci`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT dla tabeli `pokoje`
--
ALTER TABLE `pokoje`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT dla tabeli `rachunki`
--
ALTER TABLE `rachunki`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `rezerwacje`
--
ALTER TABLE `rezerwacje`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT dla tabeli `stanowiska`
--
ALTER TABLE `stanowiska`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
