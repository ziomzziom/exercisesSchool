<!DOCTYPE html>
<head>
    <meta charset="utf-8" />
    <title>Szkoła Ponadgimnazjalna</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
    <?php
        $polacz=mysqli_connect('localhost','root', '', 'szkola2');
        
        $zapytanie1=mysqli_query($polacz, "SELECT imie, nazwisko FROM uczen; ");
        $dane1=mysqli_fetch_array($zapytanie1);

        $zapytanie2=mysqli_query($polacz, "SELECT imie, nazwisko FROM uczen WHERE id=2; ");
        $dane2=mysqli_fetch_array($zapytanie2);

        $zapytanie3=mysqli_query($polacz, "SELECT AVG(ocena) FROM uczen, ocena WHERE uczen.id=2 AND przedmiot_id=1 AND uczen.id=uczen_id; ");
        $dane3=mysqli_fetch_array($zapytanie3);

        mysqli_close($polacz);
    ?>
</head>
<body>

    <div id="container">
        <div id="baner">
            <h1>Oceny uczniów: język polski</h1>
        </div>

        <div id="lewy">
            <h2>Lista uczniów</h2>
            <?php
                echo "<ol>";
                do{
                    echo "<li>".$dane1[0]." ".$dane1[1]."</li><br>";
                }while ($dane1=mysqli_fetch_array($zapytanie1));
                    echo "</ol>";
            ?>
        </div>

        <div id="prawy">
            <h2>Uczeń: <?php echo $dane2[0]." ".$dane2[1]; ?> </h2> 
            <p>Średnia z ocen z języka polskiego: <?php echo $dane3[0]; ?></p>
        </div>

        <div id="stopka">
            <h3>Zespół Szkół Ponadgimnazjalnych</h3>
            <p>Stronę opracował: 00000000003</p>
        </div>
    </div>

</body>
</html>