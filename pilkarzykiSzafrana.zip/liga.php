<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piłka nożna</title>
    <link rel="stylesheet" href="styl2.css">
</head>
<body>
        <div class="baner">
            <h3>Reprezentacja Polski w piłce nożnej</h3>
            <img src="obraz1.jpg" alt="reprezentacja">
        </div>
        <div class="lewy">
            <form action="liga.php" method="post">
                <select name="pozycja">
                    <option value="1">Bramkarze</option>
                    <option value="2">Obrońcy</option>
                    <option value="3">Pomocnicy</option>
                    <option value="4">Napastnicy</option>
                </select>
                <button type="submit">Zobacz</button>
            </form>
            
            <img src="zad2.png" alt="piłka">
            <p>Autor: 0000000000000</p>
        </div>
        <div class="prawy">
            <ol>
            <?php
                $polacz = mysqli_connect('localhost','root','','pilkarzyki');  
                $pozycja = $_POST['pozycja'];
                
                $pytanie1 = "SELECT zawodnik.imie, zawodnik.nazwisko 
                FROM zawodnik WHERE pozycja_id=".$pozycja;
                $zapytanie1=mysqli_query($polacz,$pytanie1);
                $dane1 = mysqli_fetch_array($zapytanie1);  

                if(isset($pozycja)){
                   
                    do{
                        echo "<li>".$dane1[0]." ".$dane1[1]."</li>";
                    }while($dane1 = mysqli_fetch_array($zapytanie1));
                } 
            ?>
            </ol>
        </div>
        <div class="glowny">
            <h3>Liga mistrzów</h3>
        </div>
        <div class="liga">
        <?php
                $zapytanie2 = mysqli_query($polacz,"SELECT liga.zespol, liga.punkty, liga.grupa 
                FROM liga ORDER BY liga.punkty DESC; ");
                $dane2 = mysqli_fetch_array($zapytanie2);
                do{
                    echo "<article><h2>$dane2[0]</h2> <h1>$dane2[1]</h1> <p>Grupa: $dane2[2]</p></article>";
                }while($dane2 = mysqli_fetch_array($zapytanie2));
                
            ?>
        </div>
</body>
</html>