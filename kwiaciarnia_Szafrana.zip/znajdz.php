<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kwiaty</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <div class="container">
        <div class="baner"><h1>Moje kwiaty</h1></div>
        <div class="lewy"><h3>Kwiaty dla Ciebie!</h3>
        <a href="https://www.swiatkwiatow.pl/">Rozpoznaj kwiaty</a><br>
    <a href="znajdz.php">Znajdź kwiaciarnię</a>
<img src="gozdzik.jpeg" alt="Goździk"></div>
        <div class="prawy">
            <img src="gerbera.jpeg" alt="gerbera"><img src="gozdzik.jpeg" alt="gozdzik"><img src="roza.jpeg" alt="róża">
        <p>Podaj miejscowość w której poszukujesz kwiaciarni: </p>
            <form action="znajdz.php" method="post">
            <input type="text" name="miejscowosc">
        <input type="submit" value="SPRAWDŹ"> <br>
        <?php
    $polacz = mysqli_connect('localhost','root','','kwiaciarnia');
    $miejscowosc = $_POST['miejscowosc'];
    $zapytanie1 = mysqli_query($polacz, "SELECT kwiaciarnie.nazwa, kwiaciarnie.ulica FROM kwiaciarnie WHERE kwiaciarnie.miasto='$miejscowosc';");
    $dane1 = mysqli_fetch_array($zapytanie1);
    do{
        echo "$dane1[0], $dane1[1]";
    }while($dane1 = mysqli_fetch_array($zapytanie1));
?>

            </form>
        </div>
        <div class="stopka"><h3>stronę opracował: 00000000000</h3></div>
    </div>
</body>
</html>