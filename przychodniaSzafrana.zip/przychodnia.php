<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Przychodnia</title>
    <link rel="stylesheet" href="przychodnia.css">
    <?php
        $polacz = mysqli_connect('localhost', 'root', '', 'przychodnia2');
        


        $zapytanie1 = mysqli_query($polacz, "SELECT pacjenci.id, pacjenci.imie,
         pacjenci.nazwisko FROM pacjenci;");
        $dane1 = mysqli_fetch_array($zapytanie1);
        
        
   
    ?>
</head>
<body>
    <div class="container">
        <div class="baner">
            <h1>PRAKTYKA LEKARZA RODZINNEGO</h1>
        </div>
        <div class="lewy">
            <h3>LISTA PACJENTÓW</h3>
                <?php
                    do{
                        echo $dane1[0]." ".$dane1[1]." ".$dane1[2]."<br>";
                    }while($dane1=mysqli_fetch_array($zapytanie1));
                ?>
            <br><br>
            <p>Podaj id:</p>
            
            <form action="pacjent.php" method="post">
                <input type="number" name="numerid"> <input type="submit" value="Pokaż dane">
            </form>
            
            <h3>LEKARZE</h3>
            <ul>
                <li>pn - śr</li>
                <ol>
                    <li>Anna Kwiatkowska</li>
                    <li>Jan Kowalewski</li>
                </ol>
                <li>czw - pt</li>
                <ol>
                    <li>Krzysztof Nowak</li>
                </ol>
            </ul>
        </div>
        <div class="prawy">
            <h2>INFORMACJE SZCZEGOLOWE O PACJENCIE</h2>
            <br><p>Brak wybranego pacjenta...</p>
        </div>
        <div class="stopka">
            <p>utworzone przez: 000000000000</p>
            <a href="kwerendy.txt">Pobierz plik z kwerendami</a>
        </div>
    </div>
</body>
</html>