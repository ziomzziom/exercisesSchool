<?php
$polacz = mysqli_connect('localhost','root','','pogotowie');

$nr_karetki = $_POST['nr_karetki'];
$ratownik1 = $_POST['ratownik1'];
$ratownik2 = $_POST['ratownik2'];
$ratownik3 = $_POST['ratownik3'];

$zapytanie1 = mysqli_query($polacz, "INSERT INTO ratownicy VALUES (null,'$nr_karetki','$ratownik1', '$ratownik2', '$ratownik3'); ");


echo "Do bazy zostało wysłane zapytanie: INSERT INTO ratownicy VALUES (null,'$nr_karetki','$ratownik1', '$ratownik2', '$ratownik3');";
?>