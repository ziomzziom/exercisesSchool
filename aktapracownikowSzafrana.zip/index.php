<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sekretariat</title>
    <link rel="stylesheet" href="styl.css">
    <?php
        $polacz = mysqli_connect('localhost', 'root', '', 'aktapracownicze');
    ?>
</head>
<body>
    <div class="lewy">
        <h1>Akta Pracownicze</h1>
        <!--skrypt-->
        <?php
            $pytanie1 = "SELECT pracownicy.imie, pracownicy.nazwisko, pracownicy.adres,
             pracownicy.miasto, pracownicy.czyRODO, pracownicy.czyBadania FROM pracownicy WHERE pracownicy.id='2'; ";
            $zapytanie1 = mysqli_query($polacz, $pytanie1);
            $dane1 = mysqli_fetch_array($zapytanie1);

            if($dane1[4]=0){
                $czyrodo = "niepodpisano";
            } else{
                $czyrodo = "podpisano";
            }

            if($dane1[5]=1){
                $czybadania = "aktualne";
            } else{
                $czybadania = "nieaktualne";
            }
            
            echo "<h3>dane</h3>
            <p>$dane1[0] $dane1[1]</p>
            <hr>
            <h3>adres</h3>
            <p>$dane1[2]</p>
            <p>$dane1[3]</p>
            <hr>
            <p>Rodo: $czyrodo</p>
            <p>Badania: $czybadania</p>
            ";
        ?>
        <hr>
        <h3>Dokumenty pracownika</h3>
        <a href="cv.txt" download="">Pobierz</a>
        <h1>Liczba zatrudnionych pracowników</h1>
        <p><?php
            $pytanie2 = "SELECT COUNT(*) FROM pracownicy; ";
            $zapytanie2 = mysqli_query($polacz, $pytanie2);
            $dane2 = mysqli_fetch_array($zapytanie2);

            echo "$dane2[0]";
        ?></p>
    </div>
    <div class="prawy">
        <?php
            $pytanie3 = "SELECT pracownicy.id, pracownicy.imie, pracownicy.nazwisko 
            FROM pracownicy WHERE pracownicy.id='2'; ";
            $zapytanie3 = mysqli_query($polacz, $pytanie3);
            $dane3 = mysqli_fetch_array($zapytanie3);

            echo "<img src='$dane3[0].jpg' alt='pracownik'>
            <h2>$dane3[1] $dane3[2]</h2>";

            $pytanie4 = "SELECT pracownicy.id, stanowiska.nazwa, stanowiska.opis FROM pracownicy, stanowiska 
            WHERE stanowiska.id = pracownicy.stanowiska_id AND pracownicy.id='2'; ";
            $zapytanie4 = mysqli_query($polacz, $pytanie4);
            $dane4 = mysqli_fetch_array($zapytanie4);

            echo "<h4>$dane4[1]</h4>
            <h5>$dane4[2]</h5>";

            mysqli_close($polacz);
        ?>
    </div>
    <div class="stopka">
        <p>Autorem aplikacji jest: Szafran Software</p>
        <ul>
            <li>skontaktuj się</li>
            <li>poznaj naszą firmę</li>
        </ul>
    </div>
</body>
</html>