<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warzywniak</title>
    <link rel="stylesheet" href="styl2.css">
    <?php
        $polacz = mysqli_connect('localhost','root','','warzywniaczek');
    ?>
</head>
<body>
    <div class="baner1">
        <h1>Internetowy sklep z eko-warzywami</h1>
    </div>
    <div class="baner2">
        <ol>
            <li>Warzywa</li>
            <li>Owoce</li>
            <li><a href="ttps://terapiasokami.pl/" target="_blank">Soki</a></li>
        </ol> 
    </div>
    <div class="glowny">
        <?php
            $pytanie1 = "SELECT nazwa, ilosc, opis, cena, zdjecie FROM produkty WHERE produkty.Rodzaje_id IN ('1', '2');";
            $zapytanie1 = mysqli_query($polacz, $pytanie1);
            $dane1 = mysqli_fetch_array($zapytanie1);
            do{
                echo "<div class='skrypciordiv'>
                <img src='$dane1[4]' alt='warzywniak'>
                <h5>$dane1[0]</h5>
                <p>opis : $dane1[2]</p>
                <p>na stanie : $dane1[1]</p>
                <h2>$dane1[3] zł</h2>
                </div>";
            }while($dane1 = mysqli_fetch_array($zapytanie1));

        ?>
    </div>
    <div class="stopka">
        <form action="" method="post">
                Nazwa: <input type="text" name="nazwa" id="">
                Cena: <input type="text" name="cena" id="">
                <button type="submit">Dodaj produkt</button>
                <?php
                    if(isset($_POST['nazwa']) && isset($_POST['cena'])){
                        $nazwa = $_POST['nazwa'];
                        $cena = $_POST['cena'];
                        
                        $pytanie2 = "INSERT INTO produkty VALUES (null, '1', '4', '$nazwa','10','','$cena','owoce.jpg'); ";
                        $zapytanie2 = mysqli_query($polacz, $pytanie2);
                    }
                    mysqli_close($polacz);
                ?>
        </form>
        <p>Stronę wykonał: PESEL</p>
    </div>
</body>
</html>