<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restauracja Kulinaria.pl</title>
    <link rel="stylesheet" href="styl4.css">
    <?php
        $polacz = mysqli_connect('localhost','root','','kluski');
        $pytanie1 = "SELECT MIN(dania.cena) FROM dania WHERE dania.typ='2'; ";
        $zapytanie1 = mysqli_query($polacz, $pytanie1);
        $dane1 = mysqli_fetch_array($zapytanie1);

    ?>
</head>
<body>
    <div class="baner">
        <h2>Restauracja Kulinaria.pl Zaprasza!</h2>
    </div>
    <div class="lewy">
        <p>Dania mięsne zamówisz już od 
            <?php
                echo "$dane1[0]";
            ?> 
        złotych</p>
        <img src="menu.jpg" alt="Pyszne spaghetti">  <br>
        <a href="menu.jpg" download="">Pobierz obraz</a>
    </div>
    <div class="srodkowy">
        <h3>Przekąski</h3>
        <?php
            $pytanie2 = "SELECT dania.id, dania.nazwa, dania.cena FROM dania WHERE dania.typ='3';";
            $zapytanie2 = mysqli_query($polacz, $pytanie2);
            $dane2 = mysqli_fetch_array($zapytanie2);
            do{
                echo "<p>$dane2[0] $dane2[1] $dane2[2]</p>";
            }while($dane2 = mysqli_fetch_array($zapytanie2));
        ?>
    </div>
    <div class="prawy">
        <h3>Napoje</h3>
        <?php
            $pytanie3 = "SELECT dania.id, dania.nazwa, dania.cena FROM dania WHERE dania.typ='4'; ";
            $zapytanie3 = mysqli_query($polacz, $pytanie3);
            $dane3 = mysqli_fetch_array($zapytanie3);
            do{
                echo "<p>$dane3[0] $dane3[1] $dane3[2]</p>";
            }while($dane3 = mysqli_fetch_array($zapytanie3));
        ?>
    </div>
    <div class="stopka">Stronę internetową opracował: 00000000000</div>
</body>
</html>