<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Odżywianie zwierząt</title>
    <link rel="stylesheet" href="style4.css">
</head>
<body>
    <div class="container">
        <div class="baner">
            <h2>DRAPIEŻNIKI I INNE</h2>
        </div>
        <div class="formularz">
            <h3>Wybierz styl życia:</h3>
            <form action="index.php" method="post">
                <select name="rodzaj" id="">
                    <option value="1">Drapieżniki</option>
                    <option value="2">Roślinożerne</option>
                    <option value="3">Padlinożerne</option>
                    <option value="4">Wszystkożerne</option>
                </select>
                <input type="submit" value="Zobacz">
            </form>
        </div>
        <div class="lewy">
            <h3>Lista zwierząt</h3>
            <?php
                $polacz=mysqli_connect("localhost","root","","drapiezniki");
                $pytanie2="SELECT gatunek, rodzaj FROM zwierzeta, odzywianie WHERE odzywianie.id=odzywianie_id;";
                $zapytanie2=mysqli_query($polacz, $pytanie2);
                $dane2=mysqli_fetch_array($zapytanie2);

                echo "<ul>";
                do{
                    echo "<li>$dane2[0] $dane2[1]</li>";
                }while($dane2=mysqli_fetch_array($zapytanie2));
                echo "</ul>";  
            ?>
        </div>
        <div class="srodkowy">
            <?php
            $rodzaj=$_POST['rodzaj'];

            if($rodzaj==1){
                echo "<h3>Drapieżniki</h3>";
            }else if($rodzaj==2){
                echo "<h3>Roślinożerne</h3>";
            }else if($rodzaj==3){
                echo "<h3>Padlinożerne</h3>";
            }else if($rodzaj==4){
                echo "<h3>Wszystkożerne</h3>";
            }

            $pytanie1="SELECT id, gatunek, wystepowanie from zwierzeta WHERE odzywianie_id=$rodzaj;";
            $zapytanie1=mysqli_query($polacz, $pytanie1);
            $dane1=mysqli_fetch_array($zapytanie1);
            do{
                echo "<p>$dane1[0].$dane1[1], $dane1[2]</p>";
            }while($dane1=mysqli_fetch_array($zapytanie1));
            mysqli_close($polacz);
            ?>
        </div>
        <div class="prawy">
            <img src="drapieznik.jpg" alt="Wilki">
        </div>
        <div class="stopka">
            <a href="http://pl.wikipedia.org" target="_blank">Poczytaj o zwierzętach na Wikipedii</a>
            autor strony: 127.0.0.1
        </div>
    </div>
</body>
</html>