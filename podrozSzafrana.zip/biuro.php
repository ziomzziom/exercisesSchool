<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wycieczki krajoznawcze</title>
    <link rel="stylesheet" href="styl4.css">
</head>
<body>
    <div class="container">
        <div class="baner">
            <h1>WITAMY W BIURZE PODRÓŻY</h1>
        </div>
        <div class="dane">
            <h3>ARCHIWUM WYCIECZEK</h3>
            <?php
                $polacz = mysqli_connect('localhost','root','','egzamin4');
                $zapytanie1 = mysqli_query($polacz, "SELECT wycieczki.id, wycieczki.cel, wycieczki.cena 
                FROM wycieczki WHERE wycieczki.dostepna='0';");
                $dane1 = mysqli_fetch_array($zapytanie1);
                do{
                    echo "$dane1[0], $dane1[1], cena: $dane1[2] <br>";
                }while($dane1 = mysqli_fetch_array($zapytanie1));
            ?>
        </div>
        <div class="lewy">
            <h3>NAJTANIEJ...</h3>
            <table>
                <tr><td>Włochy</td>
                <td>od 1200 zł</td></tr>
                <tr><td>Francja</td>
                <td>od 1200zł</td></tr>
                <tr><td>Hiszpania</td>
                <td>od 1400 zł</td></tr>
            </table>
        </div>
        <div class="srodkowy">
            <h3>TU BYLISMY</h3>
            <?php
                $pytanie2 = "SELECT zdjecia.nazwaPliku, zdjecia.podpis 
                FROM zdjecia ORDER BY zdjecia.podpis DESC;";
                $zapytanie2 = mysqli_query($polacz, $pytanie2);
                $dane2 = mysqli_fetch_array($zapytanie2);
                
                do{
                    echo "<img src='$dane2[0]' alt='$dane2[1]'>";
                }while($dane2 = mysqli_fetch_array($zapytanie2));
            ?>
        </div>
        <div class="prawy">
            <h3>SKONTAKTUJ SIĘ</h3>
            <a href="mailto:wycieczki@wycieczki.pl">Napisz do nas</a>
            <p>telefon: 555666777</p>
        </div>
        <div class="stopka">
            <p>Stronę wykonał: Szafran Software</p>
        </div>
    </div>
</body>
</html>