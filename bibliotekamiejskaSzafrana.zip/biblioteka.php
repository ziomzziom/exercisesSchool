<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biblioteka publiczna</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <div class="container">
        <div class="baner">
            <h2>Miejska Biblioteka Publiczna w Książkowicach</h2>
        </div>
        <div class="lewy">
            <h2>Dodaj czytelnika</h2>
            <form action="biblioteka.php" method="post">
                <p>Imię: <input type="text" name="imie"> <br>
                Nazwisko: <input type="text" name="nazwisko"> <br>
                Rok urodzenia: <input type="number" name="rok"></p>
                <button type="submit">DODAJ</button>
                <?php
                    $polacz=mysqli_connect('localhost','root','','biblioteka3');
                    
                    $imie=$_POST['imie'];
                    $nazwisko=$_POST['nazwisko'];
                    $rok=$_POST['rok'];

                    $kod = strtoupper(substr($imie,0,2).substr($nazwisko,0,2).substr($rok,-2));
                    
                    $pytanie1 = "INSERT INTO czytelnicy VALUES (null, '$imie', '$nazwisko', '$kod'); ";
                    $zapytanie1 = mysqli_query($polacz,$pytanie1);
                    
                    echo "<h3>Użytkownik $imie $nazwisko został dodany do bazy</h3>";
                ?>
            </form>
        </div>
        <div class="srodkowy">
            <img src="biblioteka.png" alt="biblioteka">
            <h4 class="pps">
                <p>ul. Czytelnicza 25</p>
                <p>12-120 Książkowice</p>
                <p>tel.: 123123123</p>
                <p>e-mail: <a href="mailto:biuro@bib.pl">biuro@bib.pl</a></p>
            </h4>
        </div>
        <div class="prawy">
            <h3>Nasi czytelnicy: </h3>
            <ul>
                <?php
                    $pytanie1 = "SELECT imie, nazwisko FROM czytelnicy;";
                    $zapytanie1 = mysqli_query($polacz,$pytanie1);
                    $dane1 = mysqli_fetch_array($zapytanie1);

                    do{
                        echo "<li>$dane1[0] $dane1[1]</li>";
                    }while($dane1=mysqli_fetch_array($zapytanie1));
            ?>
            </ul>
        </div>
        
        <div class="stopka">
            <p>Projekt witryny: Szafran Software</p>
        </div>
    </div>
</body>
</html>