<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hurtownia</title>
    <link rel="stylesheet" href="styl1.css">
</head>
<body>
    <div class="container">
        <div class="logo">
            <img src="komputer.png" alt="hurtownia komputerowa">
        </div>
        <div class="lista">
            <ul>
                <li>Sprzęt</li>
                <ol><li>Procesory</li>
                <li>Pamięci RAM</li>
                <li>Monitory</li>
                <li>Obudowy</li>
                <li>Karty graficzne</li>
                <li>Dyski twarde</li></ol>
                <li>Oprogramowanie</li>
            </ul>
        </div>
        <div class="formularz">
            <h2>Hurtownia komputerowa</h2>
            <form action="" method="post">
                <p>Wybierz kategorię sprzętu
                <input type="number" name="kategoria">
                <button type="submit">SPRAWDŹ</button>
                </p>
            </form>
        </div>
        <div class="glowny">
            <h1>Podzespoły we wskazanej kategorii</h1>
            <?php
               error_reporting(0);
                $polacz = mysqli_connect('localhost','root','','sklep');
                $kategoria = $_POST['kategoria'];
                $zapytanie1 = mysqli_query($polacz, "SELECT podzespoly.nazwa, podzespoly.opis, podzespoly.cena 
                FROM podzespoly WHERE podzespoly.typy_id='$kategoria';");
                $dane1=mysqli_fetch_array($zapytanie1);
                do{
                    echo "<p>$dane1[0]$dane1[1] CENA: $dane1[2]</p>";
                }while($dane1=mysqli_fetch_array($zapytanie1));
                mysqli_close($polacz);
            ?>
        </div>
        <div class="stopka">
            <h3>Hurtownia działa od poniedziałku do soboty w godzinach 7<sup>00</sup> - 16<sup>00</sup></h3>
            <p><a href="mailto:bok@hurtownia.pl">Napisz do nas</a>
                 Partnerzy: <a href="http://intel.pl/">Intel</a> 
                 <a href="http://amd.pl/">AMD</a>
            </p>
            <p>Stronę wykonał: 00000000000</p>
        </div>
    </div>
</body>
</html>