<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Turystyka moja pasja</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <div class="baner">
        <h1>Podróże z uśmiechem</h1>
    </div>
    <div class="ciasteczka">
        <?php
            setcookie("cookie", 1, 0);
            
            echo 'Witaj! Nasza strona używa ciasteczek <br>';

            if(isset($_COOKIE['cookie'])){
                echo 'Witaj ponownie na naszej stronie';
            } else {
                echo 'Brak ciasteczka o nazwie aktywacja';
            }          
        ?>
    </div>
    <div class="lewy">
        <h2>Nasze wycieczki</h2>
        <ol>
            <li>autokarowe</li>
            <ul>
                <li>po Polsce</li>
                <li>do Niemiec i Czech</li>
            </ul>
            <li>samolotem</li>
            <ul>
                <li>Grecja</li>
                <li>Barcelona</li>
                <li>Wenecja</li>
            </ul>
        </ol>
        <h2>Pobierz dokumenty</h2>
        <p><a href="regulamin.txt">Regulamin biura podróży</a></p>
        <p><a href="http://galeria.pl/">Zdjęcia z naszych wycieczek</a></p>
    </div>
    <div class="prawy">
        <table>
            <tr><td><img src="polska.jpg" alt="Zwiedzanie Kraakowa"></td>
            <td><img src="wlochy.jpg" alt="Wenecja i nie tylko"></td></tr>

            <tr><td><img src="grecja.jpg" alt="Gorące greckie wyspy"></td>
            <td><img src="hiszpania.jpg" alt="Słoneczna Barcelona"></td></tr>
        </table>
    </div>
    <div class="stopka">
        <p>Stronę przygotował: 00000000000</p>
    </div>
</body>
</html>