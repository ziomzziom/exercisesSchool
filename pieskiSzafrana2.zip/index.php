<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum o psach</title>
    <link rel="stylesheet" href="styl.css">
    <?php
        $polacz = mysqli_connect('localhost','root','','forumpsy2');
        $zapytanie1 = mysqli_query($polacz,"SELECT konta.nick, konta.postow, pytania.pytanie FROM konta, pytania 
        WHERE pytania.konta_id = konta.id AND konta.id ='1';");
        $dane1 = mysqli_fetch_array($zapytanie1);
    ?>
</head>
<body>
    <div class="container">
        <div class="baner">
            <h1>Forum miłośników psów</h1>
        </div>
        <div class="lewy">
            <img src="Avatar.png" alt="Użytkownik forum"> <br>
            <!--skrypt--> 
            <?php
                echo '<h4>Użytkownik: '.$dane1[0].'</h4>';
                echo '<p>'.$dane1[1].' postów na forum</p>';
                echo '<p>'.$dane1[2].'</p>';
            ?>
            <video controls>
                <source src="video.mp4" type="video/mp4">
                <source src="video.mp4" type="video/ogg">
            </video>
        </div>
        <div class="prawy">
            <form action="index.php" method="post">
                <textarea name="odpowiedz" cols="40" rows="4"></textarea> <br>
                <button type="submit">Dodaj odpowiedź</button>
                <h2>Odpowiedzi na pytanie</h2>
                <?php
                        $odpowiedz = $_POST['odpowiedz'];
                        if(!empty($odpowiedz)){
                            $zapytanie2 = mysqli_query($polacz, "INSERT INTO odpowiedzi VALUES (null,'1','5','$odpowiedz');");
                        }else{
                            echo 'Błąd danych';
                        }
                    ?>
                <ol>
                    <?php
                        $zapytanie3 = mysqli_query($polacz, "SELECT odpowiedzi.id, odpowiedzi.odpowiedz, konta.nick FROM odpowiedzi,konta 
                        WHERE odpowiedzi.konta_id=konta.id AND odpowiedzi.Pytania_id='1';");
                        $dane3 = mysqli_fetch_array($zapytanie3);
                        do{
                            echo '<li>'.$dane3[1].' '.'<em>'.$dane3[2].'</em>'.'</li> <hr>';
                        }while($dane3 = mysqli_fetch_array($zapytanie3));
                    ?>
                </ol>
            </form>
        </div>
        <div class="stopka">
            <p>Autor: 000000000000 <a href="http://mojestrony.pl/" target="_blank">Zobacz nasze realizacje</a></p>
        </div>
    </div>
</body>
</html>